# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/spoddub/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/spoddub/python-project-49/actions)\n<a href="https://codeclimate.com/github/spoddub/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/16ef1f470d199e7dc98c/maintainability" /></a>\n\nHow to install: \n\npip install --user+https://github.com/spoddub/python-project-49.git\n\nGame 1: Is That Even?\n\n[![asciicast](https://asciinema.org/a/556049.svg)](https://asciinema.org/a/556049)\n\nGame 2: Calculator\n\n[![asciicast](https://asciinema.org/a/556053.svg)](https://asciinema.org/a/556053)\n\nGame 3: Greatest Common Divisor\n\n<a href="https://asciinema.org/a/556251" target="_blank"><img src="https://asciinema.org/a/556251.svg" /></a>\n\nGame 4: Progression\n\n<a href="https://asciinema.org/a/556253" target="_blank"><img src="https://asciinema.org/a/556253.svg" /></a>\n\nGame 5: Prime Number\n\n<a href="https://asciinema.org/a/556256" target="_blank"><img src="https://asciinema.org/a/556256.svg" /></a>\n',
    'author': 'spoddub',
    'author_email': 'spoddub98@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
