### Hexlet tests and linter status:
[![Actions Status](https://github.com/spoddub/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/spoddub/python-project-49/actions)
<a href="https://codeclimate.com/github/spoddub/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/16ef1f470d199e7dc98c/maintainability" /></a>

How to install: 

pip install --user+https://github.com/spoddub/python-project-49.git

Game 1: Is That Even?

[![asciicast](https://asciinema.org/a/556049.svg)](https://asciinema.org/a/556049)

Game 2: Calculator

[![asciicast](https://asciinema.org/a/556053.svg)](https://asciinema.org/a/556053)

Game 3: Greatest Common Divisor

<a href="https://asciinema.org/a/556251" target="_blank"><img src="https://asciinema.org/a/556251.svg" /></a>

Game 4: Progression

<a href="https://asciinema.org/a/556253" target="_blank"><img src="https://asciinema.org/a/556253.svg" /></a>

Game 5: Prime Number

<a href="https://asciinema.org/a/556256" target="_blank"><img src="https://asciinema.org/a/556256.svg" /></a>
